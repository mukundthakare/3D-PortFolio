what is three.js ?
- 

What can you with three.js ?
-

what did you implemeted in three.js ?
- We had builded our own "3D portfolio" and hosted it on the github.

have you guys done any group project ?
- 

what is git ?
- 

some of the git operations ?
push
pull
fetch
commit
merge
delete

implementations - 
    what tech did you use ?
    - javascript - as a coding language.
    - node.js - to install packages build our javascript code and serve it on the browser.
    - three.js - to implment the 3D scene for the portfolio.
    - IDE - visual studio code.

    What did guys leanred from this project ?
    - HTML
    - Javascript
    - setting up a sample three.js (normal web application)
    - three.js
    - node.js

Technical things - 
1) What is javascript ?
    -https://www.w3schools.com/js/

2) node.js
    - used to installing different packages which are required for our project.
    - used to provide a runtime environment for our javascrtipt code to run
    - TODO - send the video link for node.js introduction
3) project code - 
    - make sure you should able to explain everything whatever interviewer asks about the project.

4) Project structure ?
    - we had implemeted a simple web application with following folder structure 
    |-portfolio
    |--node_modules
    |--index.html
    |--stle.css
    |--src
    |---main.js
    |-- package.json

5) what is package.json ?
    - Todo send video to understand package.json
    - contains all the informations about the project
     - install dependecnices 
       -- dev ?
        - vite
       -- depe ?
        - three.js

6) What is vite ?
  -https://vitejs.dev/guide/

7) What things's you must know about the three.js ?
 - Scene
 - Camera
 - Geometry
 - Material
 - Mesh
 - light
 - renderer

8) What are bare minimum information is required to set up a thee.js project ?
    - Scene
    - Camera
    - Geometry
    - Material
    - Mesh
    - add mesh into the scene

9) HTML ?
    - TODO 
    - intro to html video 

10) git ?
    - todo git video  
